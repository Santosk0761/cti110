#Kyler Santos
#11/27/2024
#P4LAB1a
#Use turtle to draw a square and a triangle

#Import the library
import turtle

#Create the turtle window and drawing object
win = turtle.Screen()
pen = turtle.Turtle()

#Set turtle options
pen.pensize(5)
pen.pencolor('orange')
pen.shape('arrow')

#Code to create square using for
for i in range(4):
    pen.forward(100)
    pen.left(90)

#Code to create triangle using while
sides = 3

while sides > 0:
    pen.forward(100)
    pen.left(120)
    sides -= 1


#Wait for user to close window
win.mainloop()
