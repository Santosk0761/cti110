#Kyler Santos
#11/27/2024
#P4LAB1b
#Use turtle to draw my first and last initials

#Turtle Setup
import turtle

win = turtle.Screen()
pen = turtle.Turtle()

pen.pensize(5)
pen.pencolor('blue')
pen.shape('arrow')

#Code that draws 'K'
pen.right(90)
pen.forward(100)
pen.left(180)
pen.forward(50)
pen.right(45)
pen.forward(70)
pen.left(180)
pen.forward(70)
pen.left(90)
pen.forward(70)
pen.left(180)
pen.forward(70)
pen.left(135)
pen.forward(50)

#Code to create space between letters
pen.penup()
pen.left(90)
pen.forward(100)
pen.pendown()

#Code that draws 'S'
pen.forward(50)
pen.left(90)
pen.forward(50)
pen.left(90)
pen.forward(50)
pen.right(90)
pen.forward(50)
pen.right(90)
pen.forward(50)


